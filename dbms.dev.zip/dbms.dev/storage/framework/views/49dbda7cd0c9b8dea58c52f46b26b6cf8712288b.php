<script>
	$(document).ready(function () {
      // $(".frmSignup").click(function(){
      // 	alert('s');
      //  $(".login-page").hide();
      //  $(".signup-page").fadeIn();
      // });
      alert('sss');
	});
</script>